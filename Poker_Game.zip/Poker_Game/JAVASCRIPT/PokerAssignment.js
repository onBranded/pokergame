var totalCards,cardsForSwap,raiseCounter, swapSuits,swapValues, timedelay3d,checkCount, timedelay2d, computerToCall, playerToCall, handSize, playerSuits, playerValues, computerSuits, computerValues,cards, newCards, playercards,computercards, result, resultcomputer, winType, computerWinType,winnings,computerwinnings, potTotal,playerBet,computerBet,counter, betcounter,pot,PlayerbetValue;

/*Test on Google Chrome & Safari*/
function poker()
{ 
  if (winnings ==null)
  {
  winnings = 0;
  computerwinnings = 0;
  }
  checkCount=0;	
  betcounter=0;
  raiseCounter=0;
  PlayerbetValue=0;
  computerToCall=0;
  potTotal = 0;
  document.getElementById("Pot").innerHTML = potTotal;
  document.getElementById("CheckButton").style.visibility ="visible";
  document.getElementById("BetSubmitButton").style.visibility ="visible";
  document.getElementById("BetSubmitButton").setAttribute("value", "Bet");
  document.getElementById("BetIncreaseButton").style.visibility ="hidden";
  document.getElementById("BetDecreaseButton").style.visibility ="hidden";
  document.getElementById("DealHandButton").style.visibility ="hidden";
  computerCardBacks();
  totalCards = 15;
  handSize = 5;
  cards = new Array(totalCards);
  playercards = new Array(handSize)
  computercards = new Array(handSize);
  cardsForSwap = new Array(handSize);
  playerSuits = new Array(handSize);
  playerValues = new Array(handSize);
  swapSuits = new Array(handSize);
  swapValues = new Array(handSize);
  computerSuits = new Array(handSize);
  computerValues = new Array(handSize);
  result = "";	
  resultcomputer = ""; 
  generateUniqueHandOfCards();
  splitIntoHands();
  determinePlayerSuitsAndValues();
  determineComputerSuitsAndValues();
  determineSwapCardsSuitsAndValues(); 
  orderPlayerValuesInDescendingSequence();
  orderComputerValuesInDescendingSequence();
  determinePlayerCardDescriptions();
  determinePlayerCardImage();
  determineComputerCardDescriptions();
  //evaluatePlayersHandOfCards();
  evaluateComputersHandOfCards();
  determineComputerWinType();
}
function pot()
{
 //pot += PlayerbetValue;
}
function betChosen()
{
if (betcounter==0)
{
 document.getElementById("BetIncreaseButton").style.visibility ="visible";
 document.getElementById("BetDecreaseButton").style.visibility ="visible";
 document.getElementById("CheckButton").style.visibility ="hidden";
 document.getElementById("FoldButton").style.visibility ="hidden";
 document.getElementById("BetSubmitButton").setAttribute("value", "Place Bet Of "+PlayerbetValue);
 betcounter++;
 }
 /*else if (betcounter==1)
 {
  document.getElementById("BetIncreaseButton").style.visibility ="visible";
  document.getElementById("BetDecreaseButton").style.visibility ="visible";
  betcounter++;
 }*/
 else if (betcounter==1 && PlayerbetValue >0)
 {
  potTotal+=PlayerbetValue;
  PlayerbetValue=0;
  betcounter=0;
  document.getElementById("Pot").innerHTML = potTotal;
  document.getElementById("BetIncreaseButton").style.visibility ="hidden";
  document.getElementById("BetDecreaseButton").style.visibility ="hidden";
  document.getElementById("BetSubmitButton").style.visibility ="hidden";
  setDelay3Decisions();
 } 
}
function raiseChosen()
{
 if (raiseCounter==0)
{
 PlayerbetValue =0;
 document.getElementById("RaiseIncreaseButton").style.visibility ="visible";
 document.getElementById("RaiseDecreaseButton").style.visibility ="visible";
 document.getElementById("CallButton").style.visibility ="hidden";
 document.getElementById("FoldButton").style.visibility ="hidden";
 document.getElementById("RaiseButton").setAttribute("value", "Raise By " + PlayerbetValue);
 raiseCounter=1;
 }
 /*else if (betcounter==1)
 {
  document.getElementById("BetIncreaseButton").style.visibility ="visible";
  document.getElementById("BetDecreaseButton").style.visibility ="visible";
  betcounter++;
 }*/
 else if (raiseCounter==1)
 {
  potTotal+= (PlayerbetValue + playerToCall);
  PlayerbetValue=0;
  betcounter=0;
  document.getElementById("Pot").innerHTML = potTotal;
  document.getElementById("RaiseIncreaseButton").style.visibility ="hidden";
  document.getElementById("RaiseDecreaseButton").style.visibility ="hidden";
  document.getElementById("RaiseButton").style.visibility ="hidden";
  setDelay3Decisions();
 } 

}


function setDelay3Decisions()
{
timedelay3d = setTimeout(decisionComputerThreeOptions,3000);
}
function setDelay2Decisions()
{
timedelay2d = setTimeout(decisionComputerTwoOptions,3000);
}
function betAmountUp()
{
if(PlayerbetValue == null)
{
PlayerbetValue = 0;
computerToCall = 0;
}
else if (PlayerbetValue <90)
{
PlayerbetValue+= 10;
computerToCall +=10;
document.getElementById("BetSubmitButton").setAttribute("value", "Place Bet Of "+PlayerbetValue);
document.getElementById("RaiseButton").setAttribute("value", "Raise By " + PlayerbetValue);
}
else if (PlayerbetValue == 90)
{
 window.alert("MAXIMUM BET IS 90");
}
}

function betAmountDown()
{
if(PlayerbetValue == null)
{
PlayerbetValue = 0;
computerToCall = 0;
}
else if (PlayerbetValue > 10 )
{
PlayerbetValue-= 10;
computerToCall-=10;
document.getElementById("BetSubmitButton").setAttribute("value", "Place Bet Of "+PlayerbetValue);
document.getElementById("RaiseButton").setAttribute("value", "Raise By " + PlayerbetValue);
}
else if (PlayerbetValue == 10)
{
 window.alert("MINIMUM BET IS 10");
}
}

function pokerStart()
{
 if (counter == null)
 {
  counter = 0;
 }
 if (counter == 0){
 document.getElementById("PokerGameArea").style.visibility ="visible";
 document.getElementById("PokerInfo").style.visibility ="visible";
 document.getElementById("ControlPanel").style.visibility ="visible";
 document.getElementById("StartGame").style.visibility ="hidden";
 document.getElementById("bottom").scrollIntoView();
 }
 /*if (counter == 1)
 {
 poker();
 }
 counter = 1;*/
 }
function generateUniqueHandOfCards()
{   
  var deckSize = 52, i;
  var uniqueNumbersRequired = cards.length, aRandomNumber;
  for (i = 0; i < uniqueNumbersRequired; )
  {
	aRandomNumber = Math.floor((Math.random() * deckSize));
	cards[i] = aRandomNumber;
	duplicateIndex = 0;
	while(cards[duplicateIndex] != aRandomNumber)
	 duplicateIndex++;
    if (i == duplicateIndex)
      i++;
  }
}
function splitIntoHands()
{
	var i,j,hello =" ", world = " ";
	var uniqueNumbersRequired = 15;
	for (i = 0; i < uniqueNumbersRequired;i++)
	{
		if(i < 5)
		{
			playercards[i] = cards[i];
			//document.write(playercards[i]+"_");
		}
		else if (i >=5 && i <10)
		{
			computercards[i-5] = cards[i];
			//document.write(computercards[i-5]+"_");
		}
		else
		{
		  cardsForSwap[i-10] =cards[i];
		}
	}
}

function determinePlayerSuitsAndValues()
{ 
  var i;	
  for (i = 0; i < playercards.length; i++)
  {
	playerSuits[i]  = Math.floor(playercards[i] / 13);
	//document.write(playerSuits[i]+"_");
	playerValues[i] = playercards[i] % 13;
	//document.write(playerValues[i]+"<BR>");
  }
}
function determineSwapCardsSuitsAndValues()
{ 
  var i;	
  for (i = 0; i < cardsForSwap.length; i++)
  {
	swapSuits[i]  = Math.floor(cardsForSwap[i] / 13);
	//document.write(playerSuits[i]+"_");
	swapValues[i] = cardsForSwap[i] % 13;
	//document.write(playerValues[i]+"<BR>");
  }
}		

function determineComputerSuitsAndValues()
{ 
  var i;	
  for (i = 0; i < computercards.length; i++)
  {
	computerSuits[i]  = Math.floor(computercards[i] / 13);
	//document.write(computerSuits[i]+"_");
	computerValues[i] = computercards[i] % 13;
	//document.write(computerValues[i]+"<BR>");
  }
}	


function orderPlayerValuesInDescendingSequence()
{
  var duplicateIndex, pass, comparison, temp;		
  var sorted = false;
  for (pass = 1; pass <= playerValues.length - 1 && !sorted; pass++)
  {
	sorted = true;
	for (comparison = 1; comparison <= playerValues.length - pass; comparison++)
	{
	  if (playerValues[comparison - 1] < playerValues[comparison])
	  {
	    temp                   = playerValues[comparison - 1];
	    playerValues[comparison - 1] = playerValues[comparison];
	    playerValues[comparison]     = temp;
		temp                   = playerSuits[comparison - 1];
	    playerSuits[comparison - 1]  = playerSuits[comparison];
	    playerSuits[comparison]      = temp;
	    sorted                 = false;
      }  
    }
  }	
}

function orderComputerValuesInDescendingSequence()
{
  var duplicateIndex, pass, comparison, temp;		
  var sorted = false;
  for (pass = 1; pass <= computerValues.length - 1 && !sorted; pass++)
  {
	sorted = true;
	for (comparison = 1; comparison <= computerValues.length - pass; comparison++)
	{
	  if (computerValues[comparison - 1] < computerValues[comparison])
	  {
	    temp                   = computerValues[comparison - 1];
	    computerValues[comparison - 1] = computerValues[comparison];
	    computerValues[comparison]     = temp;
		temp                   = computerSuits[comparison - 1];
	    computerSuits[comparison - 1]  = computerSuits[comparison];
	    computerSuits[comparison]      = temp;
	    sorted                 = false;
      }  
    }
  }	
}

function determinePlayerCardDescriptions()
{
  var i;	
  for (i = 0; i < playercards.length; i++)
  {
    switch(playerValues[i])
    {
      case 0:  result += "Two of ";   break;
      case 1:  result += "Three of "; break;
      case 2:  result += "Four of ";  break;
      case 3:  result += "Five of ";  break;
      case 4:  result += "Six of ";   break;
      case 5:  result += "Seven of "; break;
      case 6:  result += "Eight of "; break;
      case 7:  result += "Nine of ";  break;
      case 8:  result += "Ten of ";   break;
      case 9:  result += "Jack of ";  break;
      case 10: result += "Queen of "; break;
      case 11: result += "King of ";  break;
      case 12: result += "Ace of ";   break;
    }
    switch(playerSuits[i])
    {
      case 0:  result += "Clubs"    + "<BR>"; break;
      case 1:  result += "Diamonds" + "<BR>"; break;
      case 2:  result += "Hearts"   + "<BR>"; break;
      case 3:  result += "Spades"   + "<BR>"; break;
    }
  } 	  
}


function determinePlayerCardImage()
{
  var i,cardsource;	
  for (i = 0; i < playercards.length; i++)
  {
  cardsource="";
  switch(playerSuits[i])
    {
      case 0:  cardsource += "../CARDBACKS/DeckOfCards/0"; break;
      case 1:  cardsource += "../CARDBACKS/DeckOfCards/1"; break;
      case 2:  cardsource += "../CARDBACKS/DeckOfCards/2"; break;
      case 3:  cardsource += "../CARDBACKS/DeckOfCards/3"; break;
    }
    switch(playerValues[i])
    {
      case 0:  cardsource += "/0.png";   break;
      case 1:  cardsource += "/1.png"; break;
      case 2:  cardsource += "/2.png";  break;
      case 3:  cardsource += "/3.png";  break;
      case 4:  cardsource += "/4.png";   break;
      case 5:  cardsource += "/5.png"; break;
      case 6:  cardsource += "/6.png"; break;
      case 7:  cardsource += "/7.png";  break;
      case 8:  cardsource += "/8.png";   break;
      case 9:  cardsource += "/9.png";  break;
      case 10: cardsource += "/10.png"; break;
      case 11: cardsource += "/11.png";  break;
      case 12: cardsource += "/12.png";   break;
    }
document.getElementById("PlayerCard"+ i).src= cardsource;	  
  } 
}
function determineComputerCardImage()
{
  var i,cardsource;	
  for (i = 0; i < computercards.length; i++)
  {
  cardsource="";
  switch(computerSuits[i])
    {
      case 0:  cardsource += "../CARDBACKS/DeckOfCards/0"; break;
      case 1:  cardsource += "../CARDBACKS/DeckOfCards/1"; break;
      case 2:  cardsource += "../CARDBACKS/DeckOfCards/2"; break;
      case 3:  cardsource += "../CARDBACKS/DeckOfCards/3"; break;
    }
    switch(computerValues[i])
    {
      case 0:  cardsource += "/0.png";   break;
      case 1:  cardsource += "/1.png"; break;
      case 2:  cardsource += "/2.png";  break;
      case 3:  cardsource += "/3.png";  break;
      case 4:  cardsource += "/4.png";   break;
      case 5:  cardsource += "/5.png"; break;
      case 6:  cardsource += "/6.png"; break;
      case 7:  cardsource += "/7.png";  break;
      case 8:  cardsource += "/8.png";   break;
      case 9:  cardsource += "/9.png";  break;
      case 10: cardsource += "/10.png"; break;
      case 11: cardsource += "/11.png";  break;
      case 12: cardsource += "/12.png";   break;
    }
document.getElementById("ComputerCard"+ i).src= cardsource;	  
  } 
  compareHands();
}
function determineComputerCardDescriptions()
{
  var i;	
  for (i = 0; i < computercards.length; i++)
  {
    switch(computerValues[i])
    {
      case 0:  resultcomputer += "Two of ";   break;
      case 1:  resultcomputer += "Three of "; break;
      case 2:  resultcomputer += "Four of ";  break;
      case 3:  resultcomputer += "Five of ";  break;
      case 4:  resultcomputer += "Six of ";   break;
      case 5:  resultcomputer += "Seven of "; break;
      case 6:  resultcomputer += "Eight of "; break;
      case 7:  resultcomputer += "Nine of ";  break;
      case 8:  resultcomputer += "Ten of ";   break;
      case 9:  resultcomputer += "Jack of ";  break;
      case 10: resultcomputer += "Queen of "; break;
      case 11: resultcomputer += "King of ";  break;
      case 12: resultcomputer += "Ace of ";   break;
    }
    switch(computerSuits[i])
    {
      case 0:  resultcomputer += "Clubs"    + "<BR>"; break;
      case 1:  resultcomputer += "Diamonds" + "<BR>"; break;
      case 2:  resultcomputer += "Hearts"   + "<BR>"; break;
      case 3:  resultcomputer += "Spades"   + "<BR>"; break;
    }
  } 	  
}


function evaluatePlayersHandOfCards()
{
  winType = 0;
  if (suitsAllTheSame())
  {
   if (valuesInConsecutiveDescendingSequence())
   {
	 if (values[0] == 12)
	   winType = 9;
	 else
	   winType = 8;
   }  
   else
     winType = 7;
  }
  else
  {
    if (valuesInConsecutiveDescendingSequence()) 
      winType = 5;  
    else 
      winType = checkOtherPossibleCombinations();  
  }
}	 

function evaluateComputersHandOfCards()
{
  computerWinType = 0;
  if (suitsComputerAllTheSame())
  {
   if (valuesComputerInConsecutiveDescendingSequence())
   {
	 if (values[0] == 12)
	   computerWinType = 9;
	 else
	   computerWinType = 8;
   }  
   else
     computerWinType = 7;
  }
  else
  {
    if (valuesComputerInConsecutiveDescendingSequence()) 
      computerWinType = 5;  
    else 
      computerWinType = checkComputerOtherPossibleCombinations();  
  }
}	
function suitsAllTheSame()
{
  var i, allSameSuit = true;	
  for (i = 0; i < playerSuits.length - 1 && allSameSuit; i++)
  {
    if(playerSuits[i] != playerSuits[i + 1])
      allSameSuit = false;
  }
  return allSameSuit;
}

function suitsComputerAllTheSame()
{
  var i, allSameSuit = true;	
  for (i = 0; i < computerSuits.length - 1 && allSameSuit; i++)
  {
    if(computerSuits[i] != computerSuits[i + 1])
      allSameSuit = false;
  }
  return allSameSuit;
}

function valuesInConsecutiveDescendingSequence()
{
  var i, consecutiveDescendingSequence = true;	
  for (i = 0; i < playerValues.length - 1 && consecutiveDescendingSequence; i++)
  {
    if(playerValues[i] != (playerValues[i + 1] + 1))
      consecutiveDescendingSequence = false;
  }
  return consecutiveDescendingSequence;
}

function valuesComputerInConsecutiveDescendingSequence()
{
  var i, consecutiveDescendingSequence = true;	
  for (i = 0; i < computerValues.length - 1 && consecutiveDescendingSequence; i++)
  {
    if(computerValues[i] != (computerValues[i + 1] + 1))
      consecutiveDescendingSequence = false;
  }
  return consecutiveDescendingSequence;
}

function checkOtherPossibleCombinations()
{
  var i, j, continueCardComparison, sameKind = 0;	
  for (i = 0; i < playerValues.length - 1; i++)                          
  {                                                                      
    continueCardComparison = true;                                       
    for (j = i + 1; j < playerValues.length && continueCardComparison; j++)
    {                                                                    
      if (playerValues[i] == playerValues[j])                                        
        sameKind++;                                                      
      else                                                               
        continueCardComparison = false;                                  
    }                                                                    
  }                      
  return sameKind;
}
function checkComputerOtherPossibleCombinations()
{
  var i, j, continueCardComparison, sameKind = 0;	
  for (i = 0; i < computerValues.length - 1; i++)                          
  {                                                                      
    continueCardComparison = true;                                       
    for (j = i + 1; j < computerValues.length && continueCardComparison; j++)
    {                                                                    
      if (computerValues[i] == computerValues[j])                                        
        sameKind++;                                                      
      else                                                               
        continueCardComparison = false;                                  
    }                                                                    
  }                      
  return sameKind;
}
           
function determinePlayerWinType()
{
  result += "<BR>" + "Hand type: ";
  switch(winType)
  {
    case 0: result += "Not a winning hand"; break;
    case 1: result += "One pair";           break;
    case 2: result += "Two pair";           break;
    case 3: result += "Three of a kind";    break;
    case 4: result += "Full house";         break;
    case 5: result += "Straight";           break;
    case 6: result += "Four of a kind";     break;
    case 7: result += "Flush";              break;
    case 8: result += "Straight flush";     break;
    case 9: result += "Royal flush";        break;
  } 	
}
function determineComputerWinType()
{
  resultcomputer += "<BR>" + "Hand type: ";
  switch(computerWinType)
  {
    case 0: resultcomputer += "Not a winning hand"; break;
    case 1: resultcomputer += "One pair";           break;
    case 2: resultcomputer += "Two pair";           break;
    case 3: resultcomputer += "Three of a kind";    break;
    case 4: resultcomputer += "Full house";         break;
    case 5: resultcomputer += "Straight";           break;
    case 6: resultcomputer += "Four of a kind";     break;
    case 7: resultcomputer += "Flush";              break;
    case 8: resultcomputer += "Straight flush";     break;
    case 9: resultcomputer += "Royal flush";        break;
  } 	
}

function compareHands()
{
if(winType > computerWinType)
  {
   winnings += potTotal;
   window.alert("Player Wins " + potTotal );
  }
 //document.write(computerWinType);
  else if(winType == computerWinType)
 { 
  if (playerValues[0] > computerValues[0])
  {
   winnings += potTotal;
   window.alert("Player Wins " + potTotal + " On Highest Card");
  }
  else
  {
   window.alert("Computer Wins " + potTotal + " On Highest Card");
  }
  }
  else
  {
   window.alert("Computer Wins " + potTotal);
  }
  document.getElementById("DealHandButton").style.visibility ="visible";
  document.getElementById("winningsToDate").innerHTML= winnings; 
  document.getElementById("computerWinningsToDate").innerHTML= computerWinnings; 
}


function determineWinnings()
{
  var money = [0, 10, 20, 30, 60, 40, 70, 50, 80, 90];
  result += "<BR>" + "Winnings for this hand are: " + money[winType] + " cents" + "<BR>" + "<BR>";
  resultcomputer += "<BR>" + "Winnings for this hand are: " + money[computerWinType] + " cents";
    if (winnings == null)
  {
  winnings = 0;
  computerWinnings=0;
  }
  //winnings += money[winType];
}

function decisionComputerThreeOptions()
{
 var aRandomNumber;
 aRandomNumber = Math.random();
 //window.alert(aRandomNumber);
 if (aRandomNumber >=0 && aRandomNumber < 0.33)
 {
  //window.alert("Hello");
  foldComputer();
 }
 else if (aRandomNumber >= 0.33 && aRandomNumber <0.66)
 {
 callComputer();
 }
 else if(aRandomNumber >= 0.66)
 {
  //window.alert("Goodbye");
  raiseComputer();
 }
}

function decisionComputerTwoOptions()
{
 var aRandomNumber;
 aRandomNumber = Math.random();
 if (aRandomNumber >=0 && aRandomNumber < 0.51)
 {
  checkComputer();
 }
 else
 {
  betComputer();
 }
}
function checkPlayer()
{
 document.getElementById("CheckButton").style.visibility ="hidden";
 document.getElementById("BetSubmitButton").style.visibility ="hidden";
 setDelay2Decisions();
}

function checkComputer()
{
  if(checkCount ==0){
  window.alert("Computer Checks. Time to Swap Cards");
  document.getElementById("cardSwapSelector").style.visibility ="visible";
document.getElementById("swapCard1").style.visibility ="visible";
 document.getElementById("swapCard2").style.visibility ="visible";
 document.getElementById("swapCard3").style.visibility ="visible";
 document.getElementById("swapCard4").style.visibility ="visible";
 document.getElementById("swapCard5").style.visibility ="visible";
  }
  else if (checkCount ==1)
  {
   window.alert("Player Checks Time To Reveal Cards");
   determineComputerCardImage();
  }
}

function betComputer()
{
  var randomBet = (Math.floor((Math.random() * 10) + 1))*10;
  playerToCall = randomBet;
  document.getElementById("CallButton").style.visibility ="visible";
  document.getElementById("RaiseButton").setAttribute("value", "Raise");
  document.getElementById("RaiseButton").style.visibility ="visible";
  document.getElementById("FoldButton").style.visibility ="visible";
  window.alert("Computer Bets " + randomBet);
  potTotal+= randomBet;
  document.getElementById("Pot").innerHTML = potTotal;
}


function callPlayer()
{
potTotal+= playerToCall;
document.getElementById("Pot").innerHTML = potTotal; 
document.getElementById("CallButton").style.visibility ="hidden";
document.getElementById("RaiseButton").style.visibility ="hidden";
document.getElementById("FoldButton").style.visibility ="hidden";
if (checkCount==0)
{
 window.alert("Player Calls " + playerToCall +" Time To Swap Cards");
 document.getElementById("cardSwapSelector").style.visibility ="visible";
 document.getElementById("swapCard1").style.visibility ="visible";
 document.getElementById("swapCard2").style.visibility ="visible";
 document.getElementById("swapCard3").style.visibility ="visible";
 document.getElementById("swapCard4").style.visibility ="visible";
 document.getElementById("swapCard5").style.visibility ="visible";
}
else if(checkCount==1)
{
 window.alert("Player Calls " + playerToCall +" Time To Reveal Cards");
 determineComputerCardImage();
}
}

function callComputer()
{
 potTotal += computerToCall;
 document.getElementById("Pot").innerHTML = potTotal;
 if (checkCount == 0)
 { 
 window.alert("Computer Calls " + computerToCall +" Time To Swap Cards");
 document.getElementById("cardSwapSelector").style.visibility ="visible";
 document.getElementById("swapCard1").style.visibility ="visible";
 document.getElementById("swapCard2").style.visibility ="visible";
 document.getElementById("swapCard3").style.visibility ="visible";
 document.getElementById("swapCard4").style.visibility ="visible";
 document.getElementById("swapCard5").style.visibility ="visible";
 }
 else if (checkCount == 1)
 {
  window.alert("Computer Calls " + computerToCall +" Time To Reveal Cards");
  determineComputerCardImage();
 }
 computerToCall = 0;
}
function raiseComputer()
{
  var randomBet = (Math.floor((Math.random() * 10) + 1))*10;
  playerToCall = randomBet;
  window.alert("Computer Raises " + randomBet);
  //randomBet+= computerToCall;
  potTotal+= randomBet;
  document.getElementById("CallButton").style.visibility ="visible";
  document.getElementById("FoldButton").style.visibility ="visible";
  document.getElementById("RaiseButton").setAttribute("value", "Raise");
  document.getElementById("Pot").innerHTML = potTotal;
  document.getElementById("RaiseButton").style.visibility ="visible";
}

function foldPlayer()
{
 //computerWinnings +=  potTotal;
 document.getElementById("winningsToDate").innerHTML= winnings; 
 //document.getElementById("computerWinningsToDate").innerHTML= computerWinnings; 
 potTotal =0;
 document.getElementById("Pot").innerHTML = potTotal;
 document.getElementById("DealHandButton").style.visibility ="visible";
 document.getElementById("FoldButton").style.visibility ="hidden";
 document.getElementById("BetSubmitButton").style.visibility ="hidden";
 document.getElementById("CheckButton").style.visibility ="hidden";
 document.getElementById("RaiseButton").style.visibility ="hidden";
 document.getElementById("CallButton").style.visibility ="hidden";
}

function foldComputer()
{
 winnings +=  potTotal;
 document.getElementById("Pot").innerHTML = potTotal;
 document.getElementById("DealHandButton").style.visibility ="visible";
 document.getElementById("FoldButton").style.visibility ="hidden";
 document.getElementById("BetSubmitButton").style.visibility ="hidden";
 document.getElementById("CheckButton").style.visibility ="hidden";
 window.alert("Computer Folds Player Wins");
 document.getElementById("winningsToDate").innerHTML= winnings; 
 document.getElementById("computerWinningsToDate").innerHTML= computerWinnings; 
 potTotal =0;
}

function swapCardOne()
{
//window.alert(playerSuits[0]);
 playerSuits[0] = swapSuits[0];
 playerValues[0] = swapValues[0];
 //window.alert(swapSuits[0]);
 document.getElementById("swapCard1").style.visibility ="hidden";
}
function swapCardTwo()
{
 playerSuits[1] = swapSuits[1];
 playerValues[1] = swapValues[1]; 
document.getElementById("swapCard2").style.visibility ="hidden";
}
function swapCardThree()
{
 playerSuits[2] = swapSuits[2];
 playerValues[2] = swapValues[2]; 
document.getElementById("swapCard3").style.visibility ="hidden";
}
function swapCardFour()
{
 playerSuits[3] = swapSuits[3];
 playerValues[3] = swapValues[3]; 
document.getElementById("swapCard4").style.visibility ="hidden";
}
function swapCardFive()
{
 playerSuits[4] = swapSuits[4];
 playerValues[4] = swapValues[4]; 
document.getElementById("swapCard5").style.visibility ="hidden";
}

function submitCardSwap()
{
 document.getElementById("cardSwapSelector").style.visibility ="hidden";
 orderPlayerValuesInDescendingSequence();
 determinePlayerCardImage();
 evaluatePlayersHandOfCards();
 determinePlayerWinType();
 document.getElementById("CheckButton").style.visibility ="visible";
 document.getElementById("BetSubmitButton").style.visibility ="visible";
 document.getElementById("BetSubmitButton").setAttribute("value", "Bet");
 document.getElementById("BetIncreaseButton").style.visibility ="hidden";
 document.getElementById("BetDecreaseButton").style.visibility ="hidden";
  document.getElementById("swapCard1").style.visibility ="hidden";
 document.getElementById("swapCard2").style.visibility ="hidden";
 document.getElementById("swapCard3").style.visibility ="hidden";
 document.getElementById("swapCard4").style.visibility ="hidden";
 document.getElementById("swapCard5").style.visibility ="hidden";
 checkCount=1;
}

function computerCardBacks()
{
var i, cardsource;
cardsource="../CARDBACKS/1.jpg";
for (i=0; i<5; i++)
{
 document.getElementById("ComputerCard"+ i).src= cardsource;	  
}
}

function pokerRules()
{
 window.open("http://www.pokerlistings.com/poker-rules-5-card-draw");
}

function exit()
{
 location.reload();
 document.getElementById("PageHeader").scrollIntoView();
}




